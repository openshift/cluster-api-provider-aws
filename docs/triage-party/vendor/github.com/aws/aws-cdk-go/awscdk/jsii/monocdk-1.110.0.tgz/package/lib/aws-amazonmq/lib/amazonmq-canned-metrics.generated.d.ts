export declare class AmazonMQMetrics {
    static cpuUtilizationAverage(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static currentConnectionsCountSum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static cpuCreditBalanceHeapUsageMaximum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static networkInSum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static networkOutSum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static totalConsumerCountSum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static totalMessageCountSum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
    static totalProducerCountSum(dimensions: {
        Broker: string;
    }): {
        namespace: string;
        metricName: string;
        dimensions: {
            Broker: string;
        };
        statistic: string;
    };
}
