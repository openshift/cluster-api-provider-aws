This folder contains vendored in CDK packages.

Some dependencies of this package are not jsii packages.
They also cannot be bundled since they are part of the monorepo.

Instead vendor them directly into the assertv2 library.
