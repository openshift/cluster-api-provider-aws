import { Metric, MetricOptions } from "../../../aws-cloudwatch";
import { Duration } from "../../../core";
import { Construct } from 'constructs';
import { IApi } from '../common/api';
import { ApiBase } from '../common/base';
import { DomainMappingOptions, IStage } from '../common/stage';
import { IHttpRouteAuthorizer } from './authorizer';
import { IHttpRouteIntegration, HttpIntegration, HttpRouteIntegrationConfig } from './integration';
import { BatchHttpRouteOptions, HttpMethod, HttpRoute } from './route';
import { HttpStage, HttpStageOptions } from './stage';
import { VpcLink, VpcLinkProps } from './vpc-link';
/**
 * (experimental) Represents an HTTP API.
 *
 * @experimental
 */
export interface IHttpApi extends IApi {
    /**
     * (deprecated) The identifier of this API Gateway HTTP API.
     *
     * @deprecated - use apiId instead
     * @attribute true
     */
    readonly httpApiId: string;
    /**
     * (experimental) Metric for the number of client-side errors captured in a given period.
     *
     * @default - sum over 5 minutes
     * @experimental
     */
    metricClientError(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the number of server-side errors captured in a given period.
     *
     * @default - sum over 5 minutes
     * @experimental
     */
    metricServerError(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the amount of data processed in bytes.
     *
     * @default - sum over 5 minutes
     * @experimental
     */
    metricDataProcessed(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the total number API requests in a given period.
     *
     * @default - SampleCount over 5 minutes
     * @experimental
     */
    metricCount(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the time between when API Gateway relays a request to the backend and when it receives a response from the backend.
     *
     * @default - no statistic
     * @experimental
     */
    metricIntegrationLatency(props?: MetricOptions): Metric;
    /**
     * (experimental) The time between when API Gateway receives a request from a client and when it returns a response to the client.
     *
     * The latency includes the integration latency and other API Gateway overhead.
     *
     * @default - no statistic
     * @experimental
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * (experimental) Add a new VpcLink.
     *
     * @experimental
     */
    addVpcLink(options: VpcLinkProps): VpcLink;
    /**
     * Add a http integration
     * @internal
     */
    _addIntegration(scope: Construct, config: HttpRouteIntegrationConfig): HttpIntegration;
}
/**
 * (experimental) Properties to initialize an instance of `HttpApi`.
 *
 * @experimental
 */
export interface HttpApiProps {
    /**
     * (experimental) Name for the HTTP API resoruce.
     *
     * @default - id of the HttpApi construct.
     * @experimental
     */
    readonly apiName?: string;
    /**
     * (experimental) The description of the API.
     *
     * @default - none
     * @experimental
     */
    readonly description?: string;
    /**
     * (experimental) An integration that will be configured on the catch-all route ($default).
     *
     * @default - none
     * @experimental
     */
    readonly defaultIntegration?: IHttpRouteIntegration;
    /**
     * (experimental) Whether a default stage and deployment should be automatically created.
     *
     * @default true
     * @experimental
     */
    readonly createDefaultStage?: boolean;
    /**
     * (experimental) Specifies a CORS configuration for an API.
     *
     * @default - CORS disabled.
     * @see https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-cors.html
     * @experimental
     */
    readonly corsPreflight?: CorsPreflightOptions;
    /**
     * (experimental) Configure a custom domain with the API mapping resource to the HTTP API.
     *
     * @default - no default domain mapping configured. meaningless if `createDefaultStage` is `false`.
     * @experimental
     */
    readonly defaultDomainMapping?: DomainMappingOptions;
    /**
     * (experimental) Specifies whether clients can invoke your API using the default endpoint.
     *
     * By default, clients can invoke your API with the default
     * `https://{api_id}.execute-api.{region}.amazonaws.com` endpoint. Enable
     * this if you would like clients to use your custom domain name.
     *
     * @default false execute-api endpoint enabled.
     * @experimental
     */
    readonly disableExecuteApiEndpoint?: boolean;
    /**
     * (experimental) Default Authorizer to applied to all routes in the gateway.
     *
     * @default - No authorizer
     * @experimental
     */
    readonly defaultAuthorizer?: IHttpRouteAuthorizer;
    /**
     * (experimental) Default OIDC scopes attached to all routes in the gateway, unless explicitly configured on the route.
     *
     * @default - no default authorization scopes
     * @experimental
     */
    readonly defaultAuthorizationScopes?: string[];
}
/**
 * (experimental) Supported CORS HTTP methods.
 *
 * @experimental
 */
export declare enum CorsHttpMethod {
    /**
     * (experimental) HTTP ANY.
     *
     * @experimental
     */
    ANY = "*",
    /**
     * (experimental) HTTP DELETE.
     *
     * @experimental
     */
    DELETE = "DELETE",
    /**
     * (experimental) HTTP GET.
     *
     * @experimental
     */
    GET = "GET",
    /**
     * (experimental) HTTP HEAD.
     *
     * @experimental
     */
    HEAD = "HEAD",
    /**
     * (experimental) HTTP OPTIONS.
     *
     * @experimental
     */
    OPTIONS = "OPTIONS",
    /**
     * (experimental) HTTP PATCH.
     *
     * @experimental
     */
    PATCH = "PATCH",
    /**
     * (experimental) HTTP POST.
     *
     * @experimental
     */
    POST = "POST",
    /**
     * (experimental) HTTP PUT.
     *
     * @experimental
     */
    PUT = "PUT"
}
/**
 * (experimental) Options for the CORS Configuration.
 *
 * @experimental
 */
export interface CorsPreflightOptions {
    /**
     * (experimental) Specifies whether credentials are included in the CORS request.
     *
     * @default false
     * @experimental
     */
    readonly allowCredentials?: boolean;
    /**
     * (experimental) Represents a collection of allowed headers.
     *
     * @default - No Headers are allowed.
     * @experimental
     */
    readonly allowHeaders?: string[];
    /**
     * (experimental) Represents a collection of allowed HTTP methods.
     *
     * @default - No Methods are allowed.
     * @experimental
     */
    readonly allowMethods?: CorsHttpMethod[];
    /**
     * (experimental) Represents a collection of allowed origins.
     *
     * @default - No Origins are allowed.
     * @experimental
     */
    readonly allowOrigins?: string[];
    /**
     * (experimental) Represents a collection of exposed headers.
     *
     * @default - No Expose Headers are allowed.
     * @experimental
     */
    readonly exposeHeaders?: string[];
    /**
     * (experimental) The duration that the browser should cache preflight request results.
     *
     * @default Duration.seconds(0)
     * @experimental
     */
    readonly maxAge?: Duration;
}
/**
 * (experimental) Options for the Route with Integration resoruce.
 *
 * @experimental
 */
export interface AddRoutesOptions extends BatchHttpRouteOptions {
    /**
     * (experimental) The path at which all of these routes are configured.
     *
     * @experimental
     */
    readonly path: string;
    /**
     * (experimental) The HTTP methods to be configured.
     *
     * @default HttpMethod.ANY
     * @experimental
     */
    readonly methods?: HttpMethod[];
    /**
     * (experimental) Authorizer to be associated to these routes.
     *
     * Use NoneAuthorizer to remove the default authorizer for the api
     *
     * @default - uses the default authorizer if one is specified on the HttpApi
     * @experimental
     */
    readonly authorizer?: IHttpRouteAuthorizer;
    /**
     * (experimental) The list of OIDC scopes to include in the authorization.
     *
     * These scopes will override the default authorization scopes on the gateway.
     * Set to [] to remove default scopes
     *
     * @default - uses defaultAuthorizationScopes if configured on the API, otherwise none.
     * @experimental
     */
    readonly authorizationScopes?: string[];
}
declare abstract class HttpApiBase extends ApiBase implements IHttpApi {
    abstract readonly apiId: string;
    abstract readonly httpApiId: string;
    abstract readonly apiEndpoint: string;
    private vpcLinks;
    /**
     * (experimental) Metric for the number of client-side errors captured in a given period.
     *
     * @experimental
     */
    metricClientError(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the number of server-side errors captured in a given period.
     *
     * @experimental
     */
    metricServerError(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the amount of data processed in bytes.
     *
     * @experimental
     */
    metricDataProcessed(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the total number API requests in a given period.
     *
     * @experimental
     */
    metricCount(props?: MetricOptions): Metric;
    /**
     * (experimental) Metric for the time between when API Gateway relays a request to the backend and when it receives a response from the backend.
     *
     * @experimental
     */
    metricIntegrationLatency(props?: MetricOptions): Metric;
    /**
     * (experimental) The time between when API Gateway receives a request from a client and when it returns a response to the client.
     *
     * The latency includes the integration latency and other API Gateway overhead.
     *
     * @experimental
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * (experimental) Add a new VpcLink.
     *
     * @experimental
     */
    addVpcLink(options: VpcLinkProps): VpcLink;
    /**
     * @internal
     */
    _addIntegration(scope: Construct, config: HttpRouteIntegrationConfig): HttpIntegration;
}
/**
 * (experimental) Attributes for importing an HttpApi into the CDK.
 *
 * @experimental
 */
export interface HttpApiAttributes {
    /**
     * (experimental) The identifier of the HttpApi.
     *
     * @experimental
     */
    readonly httpApiId: string;
    /**
     * (experimental) The endpoint URL of the HttpApi.
     *
     * @default - throws an error if apiEndpoint is accessed.
     * @experimental
     */
    readonly apiEndpoint?: string;
}
/**
 * (experimental) Create a new API Gateway HTTP API endpoint.
 *
 * @experimental
 * @resource AWS::ApiGatewayV2::Api
 */
export declare class HttpApi extends HttpApiBase {
    /**
     * (experimental) Import an existing HTTP API into this CDK app.
     *
     * @experimental
     */
    static fromHttpApiAttributes(scope: Construct, id: string, attrs: HttpApiAttributes): IHttpApi;
    /**
     * (experimental) A human friendly name for this HTTP API.
     *
     * Note that this is different from `httpApiId`.
     *
     * @experimental
     */
    readonly httpApiName?: string;
    /**
     * (experimental) The identifier of this API Gateway API.
     *
     * @experimental
     */
    readonly apiId: string;
    /**
     * (experimental) The identifier of this API Gateway HTTP API.
     *
     * @experimental
     */
    readonly httpApiId: string;
    /**
     * (experimental) Specifies whether clients can invoke this HTTP API by using the default execute-api endpoint.
     *
     * @experimental
     */
    readonly disableExecuteApiEndpoint?: boolean;
    /**
     * (experimental) The default stage of this API.
     *
     * @experimental
     */
    readonly defaultStage: IStage | undefined;
    private readonly _apiEndpoint;
    private readonly defaultAuthorizer?;
    private readonly defaultAuthorizationScopes?;
    /**
     * @experimental
     */
    constructor(scope: Construct, id: string, props?: HttpApiProps);
    /**
     * (experimental) Get the default endpoint for this API.
     *
     * @experimental
     */
    get apiEndpoint(): string;
    /**
     * (experimental) Get the URL to the default stage of this API.
     *
     * Returns `undefined` if `createDefaultStage` is unset.
     *
     * @experimental
     */
    get url(): string | undefined;
    /**
     * (experimental) Add a new stage.
     *
     * @experimental
     */
    addStage(id: string, options: HttpStageOptions): HttpStage;
    /**
     * (experimental) Add multiple routes that uses the same configuration.
     *
     * The routes all go to the same path, but for different
     * methods.
     *
     * @experimental
     */
    addRoutes(options: AddRoutesOptions): HttpRoute[];
}
export {};
