import * as codepipeline from "../../aws-codepipeline";
/**
 * (experimental) Low-level class for generic CodePipeline Actions.
 *
 * If you're implementing your own IAction,
 * prefer to use the Action class from the codepipeline module.
 *
 * @experimental
 */
export declare abstract class Action extends codepipeline.Action {
    /**
     * (experimental) This is a renamed version of the {@link IAction.actionProperties} property.
     *
     * @experimental
     */
    protected readonly providedActionProperties: codepipeline.ActionProperties;
    /**
     * @experimental
     */
    protected constructor(actionProperties: codepipeline.ActionProperties);
}
