import { Stage } from './stage';
/**
 * (experimental) Initialization props for apps.
 *
 * @experimental
 */
export interface AppProps {
    /**
     * (experimental) Automatically call `synth()` before the program exits.
     *
     * If you set this, you don't have to call `synth()` explicitly. Note that
     * this feature is only available for certain programming languages, and
     * calling `synth()` is still recommended.
     *
     * @default true if running via CDK CLI (`CDK_OUTDIR` is set), `false`
     * otherwise
     * @experimental
     */
    readonly autoSynth?: boolean;
    /**
     * (experimental) The output directory into which to emit synthesized artifacts.
     *
     * @default - If this value is _not_ set, considers the environment variable `CDK_OUTDIR`.
     *   If `CDK_OUTDIR` is not defined, uses a temp directory.
     * @experimental
     */
    readonly outdir?: string;
    /**
     * (experimental) Include construct creation stack trace in the `aws:cdk:trace` metadata key of all constructs.
     *
     * @default true stack traces are included unless `aws:cdk:disable-stack-trace` is set in the context.
     * @experimental
     */
    readonly stackTraces?: boolean;
    /**
     * (deprecated) Include runtime versioning information in the Stacks of this app.
     *
     * @default Value of 'aws:cdk:version-reporting' context key
     * @deprecated use `versionReporting` instead
     */
    readonly runtimeInfo?: boolean;
    /**
     * (experimental) Include runtime versioning information in the Stacks of this app.
     *
     * @default Value of 'aws:cdk:version-reporting' context key
     * @experimental
     */
    readonly analyticsReporting?: boolean;
    /**
     * (experimental) Additional context values for the application.
     *
     * Context set by the CLI or the `context` key in `cdk.json` has precedence.
     *
     * Context can be read from any construct using `node.getContext(key)`.
     *
     * @default - no additional context
     * @experimental
     */
    readonly context?: {
        [key: string]: any;
    };
    /**
     * (experimental) Include construct tree metadata as part of the Cloud Assembly.
     *
     * @default true
     * @experimental
     */
    readonly treeMetadata?: boolean;
}
/**
 * (experimental) A construct which represents an entire CDK app. This construct is normally the root of the construct tree.
 *
 * You would normally define an `App` instance in your program's entrypoint,
 * then define constructs where the app is used as the parent scope.
 *
 * After all the child constructs are defined within the app, you should call
 * `app.synth()` which will emit a "cloud assembly" from this app into the
 * directory specified by `outdir`. Cloud assemblies includes artifacts such as
 * CloudFormation templates and assets that are needed to deploy this app into
 * the AWS cloud.
 *
 * @see https://docs.aws.amazon.com/cdk/latest/guide/apps.html
 * @experimental
 */
export declare class App extends Stage {
    /**
     * (experimental) Checks if an object is an instance of the `App` class.
     *
     * @param obj The object to evaluate.
     * @returns `true` if `obj` is an `App`.
     * @experimental
     */
    static isApp(obj: any): obj is App;
    /**
     * (experimental) Initializes a CDK application.
     *
     * @param props initialization properties.
     * @experimental
     */
    constructor(props?: AppProps);
    private loadContext;
}
