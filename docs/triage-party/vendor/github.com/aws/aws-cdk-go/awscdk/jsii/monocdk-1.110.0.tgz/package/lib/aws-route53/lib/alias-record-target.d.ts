import { IHostedZone } from './hosted-zone-ref';
import { IRecordSet } from './record-set';
/**
 * (experimental) Classes that are valid alias record targets, like CloudFront distributions and load balancers, should implement this interface.
 *
 * @experimental
 */
export interface IAliasRecordTarget {
    /**
     * (experimental) Return hosted zone ID and DNS name, usable for Route53 alias targets.
     *
     * @experimental
     */
    bind(record: IRecordSet, zone?: IHostedZone): AliasRecordTargetConfig;
}
/**
 * (experimental) Represents the properties of an alias target destination.
 *
 * @experimental
 */
export interface AliasRecordTargetConfig {
    /**
     * (experimental) Hosted zone ID of the target.
     *
     * @experimental
     */
    readonly hostedZoneId: string;
    /**
     * (experimental) DNS name of the target.
     *
     * @experimental
     */
    readonly dnsName: string;
}
