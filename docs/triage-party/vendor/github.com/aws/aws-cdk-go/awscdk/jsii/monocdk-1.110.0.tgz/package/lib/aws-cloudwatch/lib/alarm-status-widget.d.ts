import { IAlarm } from './alarm-base';
import { ConcreteWidget } from './widget';
/**
 * (experimental) Properties for an Alarm Status Widget.
 *
 * @experimental
 */
export interface AlarmStatusWidgetProps {
    /**
     * (experimental) CloudWatch Alarms to show in widget.
     *
     * @experimental
     */
    readonly alarms: IAlarm[];
    /**
     * (experimental) The title of the widget.
     *
     * @default 'Alarm Status'
     * @experimental
     */
    readonly title?: string;
    /**
     * (experimental) Width of the widget, in a grid of 24 units wide.
     *
     * @default 6
     * @experimental
     */
    readonly width?: number;
    /**
     * (experimental) Height of the widget.
     *
     * @default 3
     * @experimental
     */
    readonly height?: number;
}
/**
 * (experimental) A dashboard widget that displays alarms in a grid view.
 *
 * @experimental
 */
export declare class AlarmStatusWidget extends ConcreteWidget {
    private readonly props;
    /**
     * @experimental
     */
    constructor(props: AlarmStatusWidgetProps);
    /**
     * (experimental) Place the widget at a given position.
     *
     * @experimental
     */
    position(x: number, y: number): void;
    /**
     * (experimental) Return the widget JSON for use in the dashboard.
     *
     * @experimental
     */
    toJson(): any[];
}
