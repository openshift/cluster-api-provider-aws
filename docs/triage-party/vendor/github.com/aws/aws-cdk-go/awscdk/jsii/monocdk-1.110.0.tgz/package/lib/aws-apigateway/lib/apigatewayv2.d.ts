import * as cdk from "../../core";
import { Construct } from "../../core";
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Api`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnApiV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.ApiKeySelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-apikeyselectionexpression
     * @deprecated
     */
    readonly apiKeySelectionExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.BasePath`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-basepath
     * @deprecated
     */
    readonly basePath?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Body`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-body
     * @deprecated
     */
    readonly body?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.BodyS3Location`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-bodys3location
     * @deprecated
     */
    readonly bodyS3Location?: CfnApiV2.BodyS3LocationProperty | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.CorsConfiguration`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-corsconfiguration
     * @deprecated
     */
    readonly corsConfiguration?: CfnApiV2.CorsProperty | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.CredentialsArn`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-credentialsarn
     * @deprecated
     */
    readonly credentialsArn?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-description
     * @deprecated
     */
    readonly description?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.DisableSchemaValidation`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-disableschemavalidation
     * @deprecated
     */
    readonly disableSchemaValidation?: boolean | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.FailOnWarnings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-failonwarnings
     * @deprecated
     */
    readonly failOnWarnings?: boolean | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Name`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-name
     * @deprecated
     */
    readonly name?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.ProtocolType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-protocoltype
     * @deprecated
     */
    readonly protocolType?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.RouteKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-routekey
     * @deprecated
     */
    readonly routeKey?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.RouteSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-routeselectionexpression
     * @deprecated
     */
    readonly routeSelectionExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Tags`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-tags
     * @deprecated
     */
    readonly tags?: any;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Target`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-target
     * @deprecated
     */
    readonly target?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Version`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-version
     * @deprecated
     */
    readonly version?: string;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Api`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Api
 */
export declare class CfnApiV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Api";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.ApiKeySelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-apikeyselectionexpression
     * @deprecated
     */
    apiKeySelectionExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.BasePath`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-basepath
     * @deprecated
     */
    basePath: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Body`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-body
     * @deprecated
     */
    body: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.BodyS3Location`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-bodys3location
     * @deprecated
     */
    bodyS3Location: CfnApiV2.BodyS3LocationProperty | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.CorsConfiguration`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-corsconfiguration
     * @deprecated
     */
    corsConfiguration: CfnApiV2.CorsProperty | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.CredentialsArn`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-credentialsarn
     * @deprecated
     */
    credentialsArn: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-description
     * @deprecated
     */
    description: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.DisableSchemaValidation`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-disableschemavalidation
     * @deprecated
     */
    disableSchemaValidation: boolean | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.FailOnWarnings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-failonwarnings
     * @deprecated
     */
    failOnWarnings: boolean | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Name`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-name
     * @deprecated
     */
    name: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.ProtocolType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-protocoltype
     * @deprecated
     */
    protocolType: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.RouteKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-routekey
     * @deprecated
     */
    routeKey: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.RouteSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-routeselectionexpression
     * @deprecated
     */
    routeSelectionExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Tags`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-tags
     * @deprecated
     */
    readonly tags: cdk.TagManager;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Target`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-target
     * @deprecated
     */
    target: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Api.Version`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html#cfn-apigatewayv2-api-version
     * @deprecated
     */
    version: string | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Api`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props?: CfnApiV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Api`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Api
 */
export declare namespace CfnApiV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-bodys3location.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface BodyS3LocationProperty {
        /**
         * (deprecated) `CfnApiV2.BodyS3LocationProperty.Bucket`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-bodys3location.html#cfn-apigatewayv2-api-bodys3location-bucket
         * @deprecated
         */
        readonly bucket?: string;
        /**
         * (deprecated) `CfnApiV2.BodyS3LocationProperty.Etag`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-bodys3location.html#cfn-apigatewayv2-api-bodys3location-etag
         * @deprecated
         */
        readonly etag?: string;
        /**
         * (deprecated) `CfnApiV2.BodyS3LocationProperty.Key`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-bodys3location.html#cfn-apigatewayv2-api-bodys3location-key
         * @deprecated
         */
        readonly key?: string;
        /**
         * (deprecated) `CfnApiV2.BodyS3LocationProperty.Version`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-bodys3location.html#cfn-apigatewayv2-api-bodys3location-version
         * @deprecated
         */
        readonly version?: string;
    }
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Api`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-api.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Api
 */
export declare namespace CfnApiV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface CorsProperty {
        /**
         * (deprecated) `CfnApiV2.CorsProperty.AllowCredentials`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html#cfn-apigatewayv2-api-cors-allowcredentials
         * @deprecated
         */
        readonly allowCredentials?: boolean | cdk.IResolvable;
        /**
         * (deprecated) `CfnApiV2.CorsProperty.AllowHeaders`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html#cfn-apigatewayv2-api-cors-allowheaders
         * @deprecated
         */
        readonly allowHeaders?: string[];
        /**
         * (deprecated) `CfnApiV2.CorsProperty.AllowMethods`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html#cfn-apigatewayv2-api-cors-allowmethods
         * @deprecated
         */
        readonly allowMethods?: string[];
        /**
         * (deprecated) `CfnApiV2.CorsProperty.AllowOrigins`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html#cfn-apigatewayv2-api-cors-alloworigins
         * @deprecated
         */
        readonly allowOrigins?: string[];
        /**
         * (deprecated) `CfnApiV2.CorsProperty.ExposeHeaders`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html#cfn-apigatewayv2-api-cors-exposeheaders
         * @deprecated
         */
        readonly exposeHeaders?: string[];
        /**
         * (deprecated) `CfnApiV2.CorsProperty.MaxAge`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-api-cors.html#cfn-apigatewayv2-api-cors-maxage
         * @deprecated
         */
        readonly maxAge?: number;
    }
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::ApiMapping`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnApiMappingV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.DomainName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-domainname
     * @deprecated
     */
    readonly domainName: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.Stage`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-stage
     * @deprecated
     */
    readonly stage: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.ApiMappingKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-apimappingkey
     * @deprecated
     */
    readonly apiMappingKey?: string;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::ApiMapping`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::ApiMapping
 */
export declare class CfnApiMappingV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::ApiMapping";
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.DomainName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-domainname
     * @deprecated
     */
    domainName: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.Stage`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-stage
     * @deprecated
     */
    stage: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::ApiMapping.ApiMappingKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-apimapping.html#cfn-apigatewayv2-apimapping-apimappingkey
     * @deprecated
     */
    apiMappingKey: string | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::ApiMapping`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnApiMappingV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Authorizer`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnAuthorizerV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizertype
     * @deprecated
     */
    readonly authorizerType: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.IdentitySource`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-identitysource
     * @deprecated
     */
    readonly identitySource: string[];
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.Name`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-name
     * @deprecated
     */
    readonly name: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerCredentialsArn`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizercredentialsarn
     * @deprecated
     */
    readonly authorizerCredentialsArn?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerResultTtlInSeconds`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizerresultttlinseconds
     * @deprecated
     */
    readonly authorizerResultTtlInSeconds?: number;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerUri`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizeruri
     * @deprecated
     */
    readonly authorizerUri?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.IdentityValidationExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-identityvalidationexpression
     * @deprecated
     */
    readonly identityValidationExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.JwtConfiguration`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-jwtconfiguration
     * @deprecated
     */
    readonly jwtConfiguration?: CfnAuthorizerV2.JWTConfigurationProperty | cdk.IResolvable;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Authorizer`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Authorizer
 */
export declare class CfnAuthorizerV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Authorizer";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizertype
     * @deprecated
     */
    authorizerType: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.IdentitySource`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-identitysource
     * @deprecated
     */
    identitySource: string[];
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.Name`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-name
     * @deprecated
     */
    name: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerCredentialsArn`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizercredentialsarn
     * @deprecated
     */
    authorizerCredentialsArn: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerResultTtlInSeconds`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizerresultttlinseconds
     * @deprecated
     */
    authorizerResultTtlInSeconds: number | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.AuthorizerUri`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-authorizeruri
     * @deprecated
     */
    authorizerUri: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.IdentityValidationExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-identityvalidationexpression
     * @deprecated
     */
    identityValidationExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Authorizer.JwtConfiguration`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html#cfn-apigatewayv2-authorizer-jwtconfiguration
     * @deprecated
     */
    jwtConfiguration: CfnAuthorizerV2.JWTConfigurationProperty | cdk.IResolvable | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Authorizer`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnAuthorizerV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Authorizer`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-authorizer.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Authorizer
 */
export declare namespace CfnAuthorizerV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-authorizer-jwtconfiguration.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface JWTConfigurationProperty {
        /**
         * (deprecated) `CfnAuthorizerV2.JWTConfigurationProperty.Audience`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-authorizer-jwtconfiguration.html#cfn-apigatewayv2-authorizer-jwtconfiguration-audience
         * @deprecated
         */
        readonly audience?: string[];
        /**
         * (deprecated) `CfnAuthorizerV2.JWTConfigurationProperty.Issuer`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-authorizer-jwtconfiguration.html#cfn-apigatewayv2-authorizer-jwtconfiguration-issuer
         * @deprecated
         */
        readonly issuer?: string;
    }
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Deployment`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnDeploymentV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Deployment.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html#cfn-apigatewayv2-deployment-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Deployment.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html#cfn-apigatewayv2-deployment-description
     * @deprecated
     */
    readonly description?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Deployment.StageName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html#cfn-apigatewayv2-deployment-stagename
     * @deprecated
     */
    readonly stageName?: string;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Deployment`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Deployment
 */
export declare class CfnDeploymentV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Deployment";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Deployment.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html#cfn-apigatewayv2-deployment-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Deployment.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html#cfn-apigatewayv2-deployment-description
     * @deprecated
     */
    description: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Deployment.StageName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-deployment.html#cfn-apigatewayv2-deployment-stagename
     * @deprecated
     */
    stageName: string | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Deployment`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnDeploymentV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::DomainName`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnDomainNameV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::DomainName.DomainName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html#cfn-apigatewayv2-domainname-domainname
     * @deprecated
     */
    readonly domainName: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::DomainName.DomainNameConfigurations`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html#cfn-apigatewayv2-domainname-domainnameconfigurations
     * @deprecated
     */
    readonly domainNameConfigurations?: Array<CfnDomainNameV2.DomainNameConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::DomainName.Tags`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html#cfn-apigatewayv2-domainname-tags
     * @deprecated
     */
    readonly tags?: any;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::DomainName`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::DomainName
 */
export declare class CfnDomainNameV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::DomainName";
    /**
     * @deprecated
     * @cloudformationAttribute RegionalDomainName
     */
    readonly attrRegionalDomainName: string;
    /**
     * @deprecated
     * @cloudformationAttribute RegionalHostedZoneId
     */
    readonly attrRegionalHostedZoneId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::DomainName.DomainName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html#cfn-apigatewayv2-domainname-domainname
     * @deprecated
     */
    domainName: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::DomainName.DomainNameConfigurations`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html#cfn-apigatewayv2-domainname-domainnameconfigurations
     * @deprecated
     */
    domainNameConfigurations: Array<CfnDomainNameV2.DomainNameConfigurationProperty | cdk.IResolvable> | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::DomainName.Tags`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html#cfn-apigatewayv2-domainname-tags
     * @deprecated
     */
    readonly tags: cdk.TagManager;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::DomainName`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnDomainNameV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::DomainName`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-domainname.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::DomainName
 */
export declare namespace CfnDomainNameV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-domainname-domainnameconfiguration.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface DomainNameConfigurationProperty {
        /**
         * (deprecated) `CfnDomainNameV2.DomainNameConfigurationProperty.CertificateArn`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-domainname-domainnameconfiguration.html#cfn-apigatewayv2-domainname-domainnameconfiguration-certificatearn
         * @deprecated
         */
        readonly certificateArn?: string;
        /**
         * (deprecated) `CfnDomainNameV2.DomainNameConfigurationProperty.CertificateName`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-domainname-domainnameconfiguration.html#cfn-apigatewayv2-domainname-domainnameconfiguration-certificatename
         * @deprecated
         */
        readonly certificateName?: string;
        /**
         * (deprecated) `CfnDomainNameV2.DomainNameConfigurationProperty.EndpointType`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-domainname-domainnameconfiguration.html#cfn-apigatewayv2-domainname-domainnameconfiguration-endpointtype
         * @deprecated
         */
        readonly endpointType?: string;
    }
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Integration`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnIntegrationV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.IntegrationType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-integrationtype
     * @deprecated
     */
    readonly integrationType: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.ConnectionType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-connectiontype
     * @deprecated
     */
    readonly connectionType?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.ContentHandlingStrategy`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-contenthandlingstrategy
     * @deprecated
     */
    readonly contentHandlingStrategy?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.CredentialsArn`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-credentialsarn
     * @deprecated
     */
    readonly credentialsArn?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-description
     * @deprecated
     */
    readonly description?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.IntegrationMethod`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-integrationmethod
     * @deprecated
     */
    readonly integrationMethod?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.IntegrationUri`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-integrationuri
     * @deprecated
     */
    readonly integrationUri?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.PassthroughBehavior`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-passthroughbehavior
     * @deprecated
     */
    readonly passthroughBehavior?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.PayloadFormatVersion`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-payloadformatversion
     * @deprecated
     */
    readonly payloadFormatVersion?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.RequestParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-requestparameters
     * @deprecated
     */
    readonly requestParameters?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.RequestTemplates`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-requesttemplates
     * @deprecated
     */
    readonly requestTemplates?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.TemplateSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-templateselectionexpression
     * @deprecated
     */
    readonly templateSelectionExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.TimeoutInMillis`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-timeoutinmillis
     * @deprecated
     */
    readonly timeoutInMillis?: number;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Integration`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Integration
 */
export declare class CfnIntegrationV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Integration";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.IntegrationType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-integrationtype
     * @deprecated
     */
    integrationType: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.ConnectionType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-connectiontype
     * @deprecated
     */
    connectionType: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.ContentHandlingStrategy`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-contenthandlingstrategy
     * @deprecated
     */
    contentHandlingStrategy: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.CredentialsArn`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-credentialsarn
     * @deprecated
     */
    credentialsArn: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-description
     * @deprecated
     */
    description: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.IntegrationMethod`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-integrationmethod
     * @deprecated
     */
    integrationMethod: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.IntegrationUri`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-integrationuri
     * @deprecated
     */
    integrationUri: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.PassthroughBehavior`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-passthroughbehavior
     * @deprecated
     */
    passthroughBehavior: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.PayloadFormatVersion`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-payloadformatversion
     * @deprecated
     */
    payloadFormatVersion: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.RequestParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-requestparameters
     * @deprecated
     */
    requestParameters: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.RequestTemplates`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-requesttemplates
     * @deprecated
     */
    requestTemplates: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.TemplateSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-templateselectionexpression
     * @deprecated
     */
    templateSelectionExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Integration.TimeoutInMillis`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integration.html#cfn-apigatewayv2-integration-timeoutinmillis
     * @deprecated
     */
    timeoutInMillis: number | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Integration`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnIntegrationV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::IntegrationResponse`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnIntegrationResponseV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.IntegrationId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-integrationid
     * @deprecated
     */
    readonly integrationId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.IntegrationResponseKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-integrationresponsekey
     * @deprecated
     */
    readonly integrationResponseKey: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ContentHandlingStrategy`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-contenthandlingstrategy
     * @deprecated
     */
    readonly contentHandlingStrategy?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ResponseParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-responseparameters
     * @deprecated
     */
    readonly responseParameters?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ResponseTemplates`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-responsetemplates
     * @deprecated
     */
    readonly responseTemplates?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.TemplateSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-templateselectionexpression
     * @deprecated
     */
    readonly templateSelectionExpression?: string;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::IntegrationResponse`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::IntegrationResponse
 */
export declare class CfnIntegrationResponseV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::IntegrationResponse";
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.IntegrationId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-integrationid
     * @deprecated
     */
    integrationId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.IntegrationResponseKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-integrationresponsekey
     * @deprecated
     */
    integrationResponseKey: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ContentHandlingStrategy`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-contenthandlingstrategy
     * @deprecated
     */
    contentHandlingStrategy: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ResponseParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-responseparameters
     * @deprecated
     */
    responseParameters: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.ResponseTemplates`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-responsetemplates
     * @deprecated
     */
    responseTemplates: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::IntegrationResponse.TemplateSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-integrationresponse.html#cfn-apigatewayv2-integrationresponse-templateselectionexpression
     * @deprecated
     */
    templateSelectionExpression: string | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::IntegrationResponse`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnIntegrationResponseV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Model`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnModelV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.Name`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-name
     * @deprecated
     */
    readonly name: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.Schema`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-schema
     * @deprecated
     */
    readonly schema: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.ContentType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-contenttype
     * @deprecated
     */
    readonly contentType?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-description
     * @deprecated
     */
    readonly description?: string;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Model`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Model
 */
export declare class CfnModelV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Model";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.Name`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-name
     * @deprecated
     */
    name: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.Schema`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-schema
     * @deprecated
     */
    schema: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.ContentType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-contenttype
     * @deprecated
     */
    contentType: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Model.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-model.html#cfn-apigatewayv2-model-description
     * @deprecated
     */
    description: string | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Model`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnModelV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Route`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnRouteV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RouteKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-routekey
     * @deprecated
     */
    readonly routeKey: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.ApiKeyRequired`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-apikeyrequired
     * @deprecated
     */
    readonly apiKeyRequired?: boolean | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.AuthorizationScopes`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-authorizationscopes
     * @deprecated
     */
    readonly authorizationScopes?: string[];
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.AuthorizationType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-authorizationtype
     * @deprecated
     */
    readonly authorizationType?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.AuthorizerId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-authorizerid
     * @deprecated
     */
    readonly authorizerId?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.ModelSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-modelselectionexpression
     * @deprecated
     */
    readonly modelSelectionExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.OperationName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-operationname
     * @deprecated
     */
    readonly operationName?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RequestModels`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-requestmodels
     * @deprecated
     */
    readonly requestModels?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RequestParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-requestparameters
     * @deprecated
     */
    readonly requestParameters?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RouteResponseSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-routeresponseselectionexpression
     * @deprecated
     */
    readonly routeResponseSelectionExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.Target`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-target
     * @deprecated
     */
    readonly target?: string;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Route`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Route
 */
export declare class CfnRouteV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Route";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RouteKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-routekey
     * @deprecated
     */
    routeKey: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.ApiKeyRequired`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-apikeyrequired
     * @deprecated
     */
    apiKeyRequired: boolean | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.AuthorizationScopes`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-authorizationscopes
     * @deprecated
     */
    authorizationScopes: string[] | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.AuthorizationType`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-authorizationtype
     * @deprecated
     */
    authorizationType: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.AuthorizerId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-authorizerid
     * @deprecated
     */
    authorizerId: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.ModelSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-modelselectionexpression
     * @deprecated
     */
    modelSelectionExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.OperationName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-operationname
     * @deprecated
     */
    operationName: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RequestModels`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-requestmodels
     * @deprecated
     */
    requestModels: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RequestParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-requestparameters
     * @deprecated
     */
    requestParameters: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.RouteResponseSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-routeresponseselectionexpression
     * @deprecated
     */
    routeResponseSelectionExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Route.Target`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html#cfn-apigatewayv2-route-target
     * @deprecated
     */
    target: string | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Route`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnRouteV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Route`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-route.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Route
 */
export declare namespace CfnRouteV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-route-parameterconstraints.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface ParameterConstraintsProperty {
        /**
         * (deprecated) `CfnRouteV2.ParameterConstraintsProperty.Required`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-route-parameterconstraints.html#cfn-apigatewayv2-route-parameterconstraints-required
         * @deprecated
         */
        readonly required: boolean | cdk.IResolvable;
    }
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::RouteResponse`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnRouteResponseV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.RouteId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-routeid
     * @deprecated
     */
    readonly routeId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.RouteResponseKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-routeresponsekey
     * @deprecated
     */
    readonly routeResponseKey: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ModelSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-modelselectionexpression
     * @deprecated
     */
    readonly modelSelectionExpression?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ResponseModels`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-responsemodels
     * @deprecated
     */
    readonly responseModels?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ResponseParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-responseparameters
     * @deprecated
     */
    readonly responseParameters?: any | cdk.IResolvable;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::RouteResponse`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::RouteResponse
 */
export declare class CfnRouteResponseV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::RouteResponse";
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.RouteId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-routeid
     * @deprecated
     */
    routeId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.RouteResponseKey`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-routeresponsekey
     * @deprecated
     */
    routeResponseKey: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ModelSelectionExpression`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-modelselectionexpression
     * @deprecated
     */
    modelSelectionExpression: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ResponseModels`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-responsemodels
     * @deprecated
     */
    responseModels: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::RouteResponse.ResponseParameters`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html#cfn-apigatewayv2-routeresponse-responseparameters
     * @deprecated
     */
    responseParameters: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::RouteResponse`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnRouteResponseV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::RouteResponse`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-routeresponse.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::RouteResponse
 */
export declare namespace CfnRouteResponseV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-routeresponse-parameterconstraints.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface ParameterConstraintsProperty {
        /**
         * (deprecated) `CfnRouteResponseV2.ParameterConstraintsProperty.Required`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-routeresponse-parameterconstraints.html#cfn-apigatewayv2-routeresponse-parameterconstraints-required
         * @deprecated
         */
        readonly required: boolean | cdk.IResolvable;
    }
}
/**
 * (deprecated) Properties for defining a `AWS::ApiGatewayV2::Stage`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html
 * @deprecated moved to package aws-apigatewayv2
 */
export interface CfnStageV2Props {
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-apiid
     * @deprecated
     */
    readonly apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.StageName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-stagename
     * @deprecated
     */
    readonly stageName: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.AccessLogSettings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-accesslogsettings
     * @deprecated
     */
    readonly accessLogSettings?: CfnStageV2.AccessLogSettingsProperty | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.AutoDeploy`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-autodeploy
     * @deprecated
     */
    readonly autoDeploy?: boolean | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.ClientCertificateId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-clientcertificateid
     * @deprecated
     */
    readonly clientCertificateId?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.DefaultRouteSettings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-defaultroutesettings
     * @deprecated
     */
    readonly defaultRouteSettings?: CfnStageV2.RouteSettingsProperty | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.DeploymentId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-deploymentid
     * @deprecated
     */
    readonly deploymentId?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-description
     * @deprecated
     */
    readonly description?: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.RouteSettings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-routesettings
     * @deprecated
     */
    readonly routeSettings?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.StageVariables`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-stagevariables
     * @deprecated
     */
    readonly stageVariables?: any | cdk.IResolvable;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.Tags`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-tags
     * @deprecated
     */
    readonly tags?: any;
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Stage`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Stage
 */
export declare class CfnStageV2 extends cdk.CfnResource implements cdk.IInspectable {
    /**
     * (deprecated) The CloudFormation resource type name for this resource class.
     *
     * @deprecated
     */
    static readonly CFN_RESOURCE_TYPE_NAME = "AWS::ApiGatewayV2::Stage";
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.ApiId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-apiid
     * @deprecated
     */
    apiId: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.StageName`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-stagename
     * @deprecated
     */
    stageName: string;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.AccessLogSettings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-accesslogsettings
     * @deprecated
     */
    accessLogSettings: CfnStageV2.AccessLogSettingsProperty | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.AutoDeploy`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-autodeploy
     * @deprecated
     */
    autoDeploy: boolean | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.ClientCertificateId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-clientcertificateid
     * @deprecated
     */
    clientCertificateId: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.DefaultRouteSettings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-defaultroutesettings
     * @deprecated
     */
    defaultRouteSettings: CfnStageV2.RouteSettingsProperty | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.DeploymentId`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-deploymentid
     * @deprecated
     */
    deploymentId: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.Description`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-description
     * @deprecated
     */
    description: string | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.RouteSettings`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-routesettings
     * @deprecated
     */
    routeSettings: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.StageVariables`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-stagevariables
     * @deprecated
     */
    stageVariables: any | cdk.IResolvable | undefined;
    /**
     * (deprecated) `AWS::ApiGatewayV2::Stage.Tags`.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html#cfn-apigatewayv2-stage-tags
     * @deprecated
     */
    readonly tags: cdk.TagManager;
    /**
     * (deprecated) Create a new `AWS::ApiGatewayV2::Stage`.
     *
     * @param scope - scope in which this resource is defined.
     * @param id - scoped id of the resource.
     * @param props - resource properties.
     * @deprecated
     */
    constructor(scope: Construct, id: string, props: CfnStageV2Props);
    /**
     * (deprecated) Examines the CloudFormation resource and discloses attributes.
     *
     * @param inspector - tree inspector to collect and process attributes.
     * @deprecated
     */
    inspect(inspector: cdk.TreeInspector): void;
    /**
     * @deprecated
     */
    protected get cfnProperties(): {
        [key: string]: any;
    };
    /**
     * @deprecated
     */
    protected renderProperties(props: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Stage`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Stage
 */
export declare namespace CfnStageV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-accesslogsettings.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface AccessLogSettingsProperty {
        /**
         * (deprecated) `CfnStageV2.AccessLogSettingsProperty.DestinationArn`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-accesslogsettings.html#cfn-apigatewayv2-stage-accesslogsettings-destinationarn
         * @deprecated
         */
        readonly destinationArn?: string;
        /**
         * (deprecated) `CfnStageV2.AccessLogSettingsProperty.Format`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-accesslogsettings.html#cfn-apigatewayv2-stage-accesslogsettings-format
         * @deprecated
         */
        readonly format?: string;
    }
}
/**
 * (deprecated) A CloudFormation `AWS::ApiGatewayV2::Stage`.
 *
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigatewayv2-stage.html
 * @deprecated moved to package aws-apigatewayv2
 * @cloudformationResource AWS::ApiGatewayV2::Stage
 */
export declare namespace CfnStageV2 {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html
     * @deprecated moved to package aws-apigatewayv2
     */
    interface RouteSettingsProperty {
        /**
         * (deprecated) `CfnStageV2.RouteSettingsProperty.DataTraceEnabled`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html#cfn-apigatewayv2-stage-routesettings-datatraceenabled
         * @deprecated
         */
        readonly dataTraceEnabled?: boolean | cdk.IResolvable;
        /**
         * (deprecated) `CfnStageV2.RouteSettingsProperty.DetailedMetricsEnabled`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html#cfn-apigatewayv2-stage-routesettings-detailedmetricsenabled
         * @deprecated
         */
        readonly detailedMetricsEnabled?: boolean | cdk.IResolvable;
        /**
         * (deprecated) `CfnStageV2.RouteSettingsProperty.LoggingLevel`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html#cfn-apigatewayv2-stage-routesettings-logginglevel
         * @deprecated
         */
        readonly loggingLevel?: string;
        /**
         * (deprecated) `CfnStageV2.RouteSettingsProperty.ThrottlingBurstLimit`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html#cfn-apigatewayv2-stage-routesettings-throttlingburstlimit
         * @deprecated
         */
        readonly throttlingBurstLimit?: number;
        /**
         * (deprecated) `CfnStageV2.RouteSettingsProperty.ThrottlingRateLimit`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apigatewayv2-stage-routesettings.html#cfn-apigatewayv2-stage-routesettings-throttlingratelimit
         * @deprecated
         */
        readonly throttlingRateLimit?: number;
    }
}
