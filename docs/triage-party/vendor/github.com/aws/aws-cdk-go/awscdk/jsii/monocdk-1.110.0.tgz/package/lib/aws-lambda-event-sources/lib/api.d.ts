import * as apigw from "../../aws-apigateway";
import * as lambda from "../../aws-lambda";
/**
 * @experimental
 */
export declare class ApiEventSource implements lambda.IEventSource {
    private readonly method;
    private readonly path;
    private readonly options?;
    /**
     * @experimental
     */
    constructor(method: string, path: string, options?: apigw.MethodOptions | undefined);
    /**
     * (experimental) Called by `lambda.addEventSource` to allow the event source to bind to this function.
     *
     * @experimental
     */
    bind(target: lambda.IFunction): void;
}
